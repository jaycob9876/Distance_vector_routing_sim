import sys
from node import NetworkNode
from topology import NODES

def usage():
    print("Type this to access the nodes seperatly (must copy exactly!!) = py app.py <node>")
    print("These are the available nodes your able access:")

    for node in NODES:
        print(f"  {node}")
        
def main():
    if len(sys.argv) != 2:
        usage()
        return
    node_name = sys.argv[1]

    if node_name not in NODES:
        print(f"Unknown node: {node_name}")
        usage()
        return
    node = NetworkNode(node_name)
    node.start()

if __name__ == "__main__":
    main()

#this is where you can access one node manually, copy the steps above to find results.
#run this page as its own from the demo.py page to test each node seperatly