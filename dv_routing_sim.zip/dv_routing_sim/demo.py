import subprocess
import sys
import time
from topology import NODES

def main():
    processes = []

    print("Distance vector routing demo now Starting!")
    print("Each of the node runs as a separate process")
    print("Type CTRL + C to stop the programme")
    print(" ")

    try:
        for node in NODES:
            process = subprocess.Popen([sys.executable, "app.py", node])
            processes.append(process)
            time.sleep(1)

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("")
        print("The demo is now stopping")

        for process in processes:
            process.terminate()

        print("Demo stopped!!")

if __name__ == "__main__":
    main()

#this file is the scaffold mode, it runs all tje nodes automatically as seperate proccess