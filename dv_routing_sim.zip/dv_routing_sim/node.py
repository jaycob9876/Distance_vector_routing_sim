import socket
import threading
import time
from datetime import datetime

from packet import Packet
from table import RoutingTable
from topology import HOST, NODES, UPDATE_INTERVAL

class NetworkNode:
    def __init__(self, name):
        if name not in NODES:
            raise ValueError("Unknown node name")

        self.name = name
        self.port = NODES[name]["port"]
        self.links = NODES[name]["links"]
        self.table = RoutingTable(name, self.links)
        self.running = False
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((HOST, self.port))

    def log(self, text):
        now = datetime.now().strftime("%H:%M:%S")
        print(f"[{now}] {self.name}: {text}", flush=True)

    def start(self):
        self.running = True
        self.log(f"started on {HOST}:{self.port}")
        self.log(f"direct links: {self.links}")
        print(self.table.show(), flush=True)

        threading.Thread(target=self.listen, daemon=True).start()
        threading.Thread(target=self.send_loop, daemon=True).start()

        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

    def stop(self):
        self.running = False
        self.sock.close()
        self.log("stopped")

    def send_loop(self):
        time.sleep(2)

        while self.running:
            self.send_update()
            time.sleep(UPDATE_INTERVAL)

    def send_update(self):
        packet = Packet.make_update(self.name, self.table.export())

        for neighbour in self.links:
            port = NODES[neighbour]["port"]
            try:
                self.sock.sendto(packet, (HOST, port))
                self.log(f"sent routing update to {neighbour}")
            except OSError:
                if self.running:
                    self.log(f"could not send update to {neighbour}")

    def listen(self):
        while self.running:
            try:
                data, = self.sock.recvfrom(4096)
                packet = Packet.read(data)
                self.handle_packet(packet)
            except OSError:
                break
            except Exception as error:
                self.log(f"message error: {error}")

    def handle_packet(self, packet):
        if packet.get("type") != Packet.UPDATE:
            self.log("ignored unknown packet")
            return
        sender = packet.get("sender")
        received_table = packet.get("table")

        if sender not in self.links:
            self.log(f"ignored update from non neighbour {sender}")
            return

        self.log(f"received routing update from {sender}")

        changed = self.table.learn_from(
            sender,
            self.links[sender],
            received_table
        )

        if changed:
            self.log("routing table have now updated")
            print(self.table.show(), flush = True)
            self.log("sending triggered update")
            self.send_update()
        else:
            self.log("there no better route found")

#this file is the main router file. each node opens a seperate UDP socket, which sends routing updates, also recives updates 
#and updates the routing table.