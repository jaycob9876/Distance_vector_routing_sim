import json
from datetime import datetime

class Packet:
    UPDATE = "ROUTE_UPDATE"

    @staticmethod
    def make_update(sender, table):
        data = {
            "type": Packet.UPDATE,
            "sender": sender,
            "time": datetime.now().strftime("H:M:S"),
            "table": table
        }
        return json.dumps(data).encode("utf-8")

    @staticmethod
    def read(data):
        return json.loads(data.decode("utf-8"))

#this section creates eand reads simplified routing messages 