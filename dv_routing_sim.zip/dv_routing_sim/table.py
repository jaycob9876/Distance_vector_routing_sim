from topology import INFINITY

class RoutingTable:
    def __init__(self, node_name, links):
        self.node_name = node_name
        self.routes = {}

        self.routes[node_name] = {
            "cost": 0,
            "next_hop": node_name,
            "source": "self"
        }

        for neighbour, cost in links.items():
            self.routes[neighbour] = {
                "cost": cost,
                "next_hop": neighbour,
                "source": "direct"
            }
    def export(self):
        return {
            destination: {
                "cost": route["cost"],
                "next_hop": route["next_hop"],
                "source": route["source"]
            }
            for destination, route in self.routes.items()
        }
    def learn_from(self, neighbour, cost_to_neighbour, neighbour_table):
        changed = False

        for destination, route in neighbour_table.items():
            if destination == self.node_name:
                continue
            advertised_cost = int(route["cost"])

            if advertised_cost >= INFINITY:
                continue
            new_cost = cost_to_neighbour + advertised_cost

            if new_cost >= INFINITY:
                new_cost = INFINITY

            if destination not in self.routes:
                self.routes[destination] = {
                    "cost": new_cost,
                    "next_hop": neighbour,
                    "source": f"via {neighbour}"
                }
                changed = True

            elif new_cost < self.routes[destination]["cost"]:
                self.routes[destination] = {
                    "cost": new_cost,
                    "next_hop": neighbour,
                    "source": f"via {neighbour}"
                }
                changed = True

        return changed

    def show(self):
        lines = []
        lines.append("")
        lines.append(f"Routing table for {self.node_name}")
        lines.append("-" * 60)
        lines.append(f"{'Destination':<15}{'Cost':<10}{'Next hop':<15}{'Source':<15}")
        lines.append("-" * 60)

        for destination in sorted(self.routes):
            route = self.routes[destination]
            lines.append(
                f"{destination:<15}"
                f"{route['cost']:<10}"
                f"{route['next_hop']:<15}"
                f"{route['source']:<15}"
            )
        lines.append("-" * 60)
        return "\n".join(lines)

#this file contains the distance vector, stores teh routing table and updates it when there is a better route.
#in this insatance it would be the neighbour