HOST = "127.0.0.1"
INFINITY = 16
UPDATE_INTERVAL = 5

NODES = {
    "Core": {
        "port": 5200,
        "links": {
            "Edge": 1,
            "Backup": 4
        }
    },
    "Edge": {
        "port": 5201,
        "links": {
            "Core": 1,
            "Access": 1,
            "Backup": 2
        }
    },
    "Access": {
        "port": 5202,
        "links": {
            "Edge": 1
        }
    },
    "Backup": {
        "port": 5203,
        "links": {
            "Core": 4,
            "Edge": 2
        }
    }
}

#this is the main scaffold(Topology). it defines the simulated networks, ports and links cost.